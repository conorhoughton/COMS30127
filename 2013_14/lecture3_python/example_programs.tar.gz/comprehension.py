numbers = [1,2,3,4,5]

cubes = [x*x*x for x in numbers]

print cubes
