hello = "hello world"

print enumerate("hello world")
