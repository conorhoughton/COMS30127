hello = "hello world"
print hello
