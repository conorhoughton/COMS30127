hello = "hello world"

for i,a in enumerate(hello):
    print i,a
print 
