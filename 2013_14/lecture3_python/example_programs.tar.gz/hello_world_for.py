hello = "hello world"

for a in hello:
    print a,
print 
