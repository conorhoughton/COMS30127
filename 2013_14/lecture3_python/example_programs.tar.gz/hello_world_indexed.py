hello = "hello world"

for i in range(0,len(hello)):
    print hello[i],
print 
