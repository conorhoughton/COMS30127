a = [0,1,2]
b = a

print a
print b

b[1]=-1

print a
print b

