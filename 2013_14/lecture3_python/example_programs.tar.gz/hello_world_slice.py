hello = "hello world"
print hello[0]
print hello[1:3]
print hello[-1]
