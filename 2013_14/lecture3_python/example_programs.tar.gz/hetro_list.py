list=[72,79,86,96,103,"Catheral Parkway"]
print list
