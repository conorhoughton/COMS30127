import random

a=random.randint(1,3)

if a==1:
    print 'one'
elif a==2:
    print 'two'
else:
    print 'three'
