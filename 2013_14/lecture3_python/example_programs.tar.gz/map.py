def cube(x):
    return x*x*x

numbers = [1,2,3,4,5]

cubes = map (cube,numbers)

print cubes
