import numpy as np
d1=np.array([1,-1,1])
d2=np.array([1,2,1])
print d1
print d2
print d1*d2
print np.dot(d1,d2)
