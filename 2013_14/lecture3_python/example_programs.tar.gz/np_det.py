import numpy as np
d1=np.array([(1,-1,3),(1,2,1),(3,1,1)])
print np.linalg.det(d1)

